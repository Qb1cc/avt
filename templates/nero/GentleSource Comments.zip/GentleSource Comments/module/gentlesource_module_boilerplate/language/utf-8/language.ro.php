<?php

/** 
 * GentleSource Module Boilerplate
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_content'                       => 'Conþinut',

'txt_enable_module'                 => 'Activeazã Boilerplate',

'txt_enable_module_description'     => 'Aceastã trãsãturã afiºeazã un meniu selectabil care vã permite sã alegeþi dintr-o listã de texte reusabile.',

'txt_module_description'            => 'Boilerplate se referã la orice text care este sau care poate fi reutilizat în contexte noi (vezi de asemenea <a href="http://en.wikipedia.org/wiki/Boilerplate_%28text%29" target="_blank">Wikipedia</a>).',
'txt_module_name'                   => 'Boilerplate',

'txt_title'                         => 'Titlu',

);








?>
