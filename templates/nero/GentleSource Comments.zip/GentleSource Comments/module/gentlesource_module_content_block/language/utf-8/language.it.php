<?php

/**
 * GentleSource Comment Script - language.it.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_error_content_block'           => 'Il tuo commento Ã¨ stato bloccato.',

'txt_block_content'                 => 'Blocca Contenuto',
'txt_block_content_description'     => 'Inserisci una o pi&uacute; parole per linea.',

'txt_moderate'                      => 'Modera',
'txt_module_description'            => 'Modera o blocca i commenti in base al loro contenuto.',
'txt_module_name'                   => 'Controllo contenuto',

'txt_notice_moderation'             => 'Il tuo commento sar&aacute; pubblicato una volta approvato.',

'txt_off'                           => 'Off',

'txt_reject'                        => 'Respingi',

);








?>
