<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_enable_module'                 => 'Label text',
'txt_enable_module_description'     => 'Description text  that appears on the module settings page.',

'txt_module_description'            => 'This is a dummy module',
'txt_module_name'                   => 'Dummy Module',

);








?>
