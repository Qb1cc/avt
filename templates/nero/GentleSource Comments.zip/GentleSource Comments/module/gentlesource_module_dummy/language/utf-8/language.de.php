<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Bezeichnung',
'txt_enable_module_description'     => 'Beschreibungstext, der auf der Moduleinstellungsseite erscheint.',

'txt_module_description'            => 'Dies ist ein Dummy-Modul',
'txt_module_name'                   => 'Dummy-Modul',

);








?>
