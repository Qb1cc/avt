<?php

/** 
 * GentleSourceModule Text Link Ads
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_ad_font_size'                  => 'M�rimea fontului leg�turii',
'txt_ads_per_row'                   => 'Leg�turi text publicitare pe linie',

'txt_background_color'              => 'Culoarea fundalului',
'txt_border_color'                  => 'Culoarea bordurii',

'txt_enable_module'                 => 'Activeaz� Leg�turile text publicitare',
'txt_enable_module_description'     => 'Afi�eaz� leg�turi din Leg�turi text publicitare.',

'txt_link_color'                    => 'Culoarea leg�turii',

'txt_module_description'            => 'Face�i bani cu situl web �i publica�i simple leg�turi text publicitare sau cump�ra�i leg�turi text publicitare pentru a m�ri traficul pe site �i a �mbun�t��i locul �n motoarele de c�utare. Mai multe informa�ii la <a href="http://www.text-link-ads.com/?ref=37444" target="_blank">Text Link Ads</a>.',
'txt_module_name'                   => 'Leg�turi text publicitare',

'txt_tla_xml_key'                   => 'Cheia XML a Leg�turilor text publicitare',
'txt_tla_xml_key_description'       => 'Pute�i g�si cheia XML �n contul Text Link Ads. Autentifica�i-v�, intra�i �n cont, merge�i la "Publisher Program", click "Install ad code", cheia XML este mai jos de domeniul sitului dvs-tr�.',

);








?>
