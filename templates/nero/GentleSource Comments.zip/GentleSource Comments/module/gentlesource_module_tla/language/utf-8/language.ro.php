<?php

/** 
 * GentleSourceModule Text Link Ads
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_ad_font_size'                  => 'Mãrimea fontului legãturii',
'txt_ads_per_row'                   => 'Legãturi text publicitare pe linie',

'txt_background_color'              => 'Culoarea fundalului',
'txt_border_color'                  => 'Culoarea bordurii',

'txt_enable_module'                 => 'Activeazã Legãturile text publicitare',
'txt_enable_module_description'     => 'Afiºeazã legãturi din Legãturi text publicitare.',

'txt_link_color'                    => 'Culoarea legãturii',

'txt_module_description'            => 'Faceþi bani cu situl web ºi publicaþi simple legãturi text publicitare sau cumpãraþi legãturi text publicitare pentru a mãri traficul pe site ºi a îmbunãtãþi locul în motoarele de cãutare. Mai multe informaþii la <a href="http://www.text-link-ads.com/?ref=37444" target="_blank">Text Link Ads</a>.',
'txt_module_name'                   => 'Legãturi text publicitare',

'txt_tla_xml_key'                   => 'Cheia XML a Legãturilor text publicitare',
'txt_tla_xml_key_description'       => 'Puteþi gãsi cheia XML în contul Text Link Ads. Autentificaþi-vã, intraþi în cont, mergeþi la "Publisher Program", click "Install ad code", cheia XML este mai jos de domeniul sitului dvs-trã.',

);








?>
