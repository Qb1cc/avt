<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Suchwörter hervorheben einschalten',
'txt_enable_module_description'     => '',

'txt_highlight_format'              => 'Formatierung der Suchwörter',
'txt_highlight_format_description'  => 'Sie können CSS verwenden, um das Suchwort optisch hervorzuheben: style="background-color:#CCCCCC;"',

'txt_module_description'            => 'Hebt das Suchwort aus dem Suchmaschinen-Referrer optisch im Text hervor.',
'txt_module_name'                   => 'Suchwörter hervorheben',

'txt_stop_words'                    => 'ein, eine, der, die, das',

);








?>
