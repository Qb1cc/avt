<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_enable_module'                 => 'Wy�wietl linki Web 2.0',
'txt_enable_module_description'     => 'W��czenie tej opcji wy�wietli liste link�w do najpopularniejszych stron Web 2.0 takich jak del.icio.us lub digg. Mo�esz zmieni� liste tych stron, edytuj�c plik link.tpl.html',

'txt_module_description'            => 'Wy�wietl linki do stron Web 2.0 takich jak del.icio.us, digg, etc.',
'txt_module_name'                   => 'Web 2.0',

'txt_post_this_page'                => 'Dodaj do',

);








?>
