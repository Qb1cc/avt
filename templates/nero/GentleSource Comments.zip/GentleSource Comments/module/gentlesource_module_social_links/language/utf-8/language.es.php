<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Mostrar enlaces a marcadores',
'txt_enable_module_description'     => 'Si activas esta función, se mostrará una lista con enlaces a servicios de marcadores tales como menéame, del.icio.us o digg en el píe de  página. Puedes modificar la lista en la plantilla link.tpl.html',

'txt_module_description'            => 'Muestra enlaces a marcadores tales como méneame, del.icio.us, digg, etc...',
'txt_module_name'                   => 'Marcadores',

'txt_post_this_page'                => 'Enviar esta página a',

);








?>
