<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Wy¶wietl linki Web 2.0',
'txt_enable_module_description'     => 'W³±czenie tej opcji wy¶wietli liste linków do najpopularniejszych stron Web 2.0 takich jak del.icio.us lub digg. Mo¿esz zmieniæ liste tych stron, edytuj±c plik link.tpl.html',

'txt_module_description'            => 'Wy¶wietl linki do stron Web 2.0 takich jak del.icio.us, digg, etc.',
'txt_module_name'                   => 'Web 2.0',

'txt_post_this_page'                => 'Dodaj do',

);








?>
