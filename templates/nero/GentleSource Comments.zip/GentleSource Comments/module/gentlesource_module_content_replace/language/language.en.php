<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_content'                       => 'Content',

'txt_enable_module'                 => 'Content Replace',

'txt_enable_module_description'     => 'This feature allows you to replace text with other text.',

'txt_module_description'            => 'This feature allows you to replace text with other text. E.g. you can place a link on a word or replace undesired text with desired text.',
'txt_module_name'                   => 'Content Replace',

'txt_title'                         => 'Title',

);








?>
