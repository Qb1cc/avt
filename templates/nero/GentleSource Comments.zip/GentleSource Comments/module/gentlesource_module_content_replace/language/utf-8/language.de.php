<?php

/**
 * GentleSource Comment Script - language.en.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_content'                       => 'Inhalt',

'txt_enable_module'                 => 'Inhalte ersetzen',

'txt_enable_module_description'     => 'Ersetzen Sie Wörter durch festgelegte Texte.',

'txt_module_description'            => 'Sie können diese Funktion nutzen, um Wörter durch anderen Text zu ersetzen. So können Sie zum Beispiel bestimmte Wörter mit einen Link hinterlegen oder unerwünschte Wörter durch erwünschten Text ersetzen.',
'txt_module_name'                   => 'Inhalte ersetzen',

'txt_title'                         => 'Titel',

);








?>
