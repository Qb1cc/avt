<?php

/**
 * GentleSource Comment Script - language.it.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_enable_mailer'                 => 'Abilita emailer commenti',
'txt_enable_mailer_description'     => 'Invia una mail di notifica ogni qual volta venga inserito un commento.',

'txt_module_description'            => 'Invia una mail di notifica ogni qual volta venga inserito un commento.',
'txt_module_name'                   => 'Mailer Commenti',

'txt_notification_mail_subject'     => 'Nuovo commento inserito',
'txt_notification_mail_text'        => 'Nuovo commento inserito',

'txt_recipient'                     => 'Recipiente',
'txt_recipient_description'         => 'Recipiente indirizzi email notifiche. Inserisci uno o pi&uacute; indirizzi email (separandoli con la virgola).',

);








?>
