<?php

/** 
 * GentleSource Comment Script - language.en.php
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset' => 'utf-8',



'txt_enable_mailer'                 => 'Activeazã Mail Comentarii',
'txt_enable_mailer_description'     => 'Trimite notificãri prin mail când un comentariu a fost postat.',

'txt_module_description'            => 'Trimite notificãri prin mail de fiecare datã când un comentariu a fost postat.',
'txt_module_name'                   => 'Mail Comentarii',

'txt_notification_mail_subject'     => 'Postare de Comentariu Nou',
'txt_notification_mail_text'        => 'A fost postat un comentariu nou.',

'txt_recipient'                     => 'Destinatar',
'txt_recipient_description'         => 'Destinatarul e-mailului de notificare.Introduceþi unul sau mai multe adrese de e-mail(separate prin virgulã).',

);








?>
