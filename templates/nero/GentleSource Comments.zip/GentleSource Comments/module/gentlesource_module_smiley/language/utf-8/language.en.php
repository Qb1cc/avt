<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset' => 'utf-8',



'txt_enable_module'                 => 'Enable Smilies/Emoticons',
'txt_enable_module_description'     => 'Replaces ASCII smilies/emoticons such as :-) or ;-) in the text with images.',

'txt_large'                         => 'Large',

'txt_module_description'            => 'Replaces ASCII smilies/emoticons such as :-) or ;-) in the text with images.',
'txt_module_name'                   => 'Smilies/Emoticons',
'txt_medium'                        => 'Medium',

'txt_size'                          => 'Size',
'txt_small'                         => 'Small',

);








?>
