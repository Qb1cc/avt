<?php

/**
 * GentleSource Comment Script - language.it.php
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language or have corrected typos, we would
 * appreciate it if you would send us the
 * translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_enable_module'                 => 'Abilita Smilies/Emoticons',
'txt_enable_module_description'     => 'Sostituisci il testo ASCII come :-) or ;-) con immagini.',

'txt_large'                         => 'Grande',

'txt_module_description'            => 'Sostituisci il testo ASCII come :-) or ;-) con immagini.',
'txt_module_name'                   => 'Smilies/Emoticons',
'txt_medium'                        => 'Medio',

'txt_size'                          => 'Dimensione',
'txt_small'                         => 'Piccolo',

);








?>
