<?php

/** 
 * GentleSource Module Smiley
 * 
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 * 
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 * 
 */




$text = array(   

'txt_charset'                       => 'iso-8859-1',



'txt_enable_module'                 => 'Activeaz� Z�mbete/Emoticoanele',
'txt_enable_module_description'     => '�nlocuire z�mbete/Emoticoane ASCII cum ar fi :-) ori ;-) �n text cu imagini.',

'txt_large'                         => 'Mare',

'txt_module_description'            => '�nlocuire z�mbete/Emoticoane ASCII cum ar fi :-) ori ;-) �n text cu imagini.',
'txt_module_name'                   => 'Z�mbete/Emoticoane',
'txt_medium'                        => 'Medie',

'txt_size'                          => 'M�rime',
'txt_small'                         => 'Mic�',

);








?>
