<?php

/**
 * GentleSource
 *
 * (C) Ralf Stadtaus http://www.gentlesource.com/
 *
 * If you have translated this file into another
 * language, we would appreciate it if you would
 * send us the translated file. Thanks :-)
 *
 */




$text = array(

'txt_charset'                       => 'iso-8859-1',



'txt_alternative_captcha'           => 'Uruchom alternatywn� Captch�',
'txt_alternative_captcha_description' => 'W przypadku nie dzia�ania standardowej Captchy, uruchom alternatywn�.',

'txt_captcha_try_again'             => '�le wpisany kod. Prosz� wpisa� ponownie poprawny kod.',
'txt_captcha_description'           => 'Aby zapobiec spam-botom, prosz� spojrze� na wygenerowany kod i wpisa� go w pole tekstowe. Je�eli kod b�dzie si� zgadza�, wiadomo�� zostanie wys�ana.',

'txt_enable_captcha'                => 'W��cz Captcha',
'txt_enable_captcha_description'    => 'Aby zapobiec spam-botom, mo�esz wymaga� od swoich go�ci na stronie wprowadzenie kodu Captcha przed wys�anie wiadomo�ci.',

'txt_garbage_collector'             => 'W��cz zbieranie �mieci',
'txt_garbage_collector_description' => 'Wszystkie wygenerowane kody Captcha s� trzymane w folderze tymczasowym. Zbieranie �mieci usuwanie je co pewien czas. Je�eli wy�aczysz t� opcje, tw�j folder �mieci Captcha b�dzie r�s� razem z przybywaj�cymi kodami.',

'txt_font_size'                     => 'Wielko�� czcionki',

'txt_image_height'                  => 'Wysoko�� obrazka',
'txt_image_width'                   => 'Szerowko�� obrazka',

'txt_module_name'                   => 'Obrazek Captcha',
'txt_module_description'            => 'Zapobieganie spam-botom.',

);








?>
