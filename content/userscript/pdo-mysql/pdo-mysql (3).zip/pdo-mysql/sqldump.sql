	
--
-- Структура таблицы `models`
--

CREATE TABLE IF NOT EXISTS `models` (
  `id` tinyint(2) NOT NULL,
  `producer_id` tinyint(3) NOT NULL,
  `model` char(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `producers`
--

CREATE TABLE IF NOT EXISTS `producers` (
  `id` tinyint(2) NOT NULL,
  `producer` char(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `models`
--
ALTER TABLE `models`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `producers`
--
ALTER TABLE `producers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `models`
--
ALTER TABLE `models`
  MODIFY `id` tinyint(2) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `producers`
--
ALTER TABLE `producers`
  MODIFY `id` tinyint(2) NOT NULL AUTO_INCREMENT;

--
-- Дамп данных таблицы `producers`
--

INSERT INTO `producers` (`id`, `producer`) VALUES
(1, 'KIA'),
(2, 'Hyundai'),
(3, 'Lada'),
(4, 'Chevrolet'),
(5, 'Opel');

--
-- Дамп данных таблицы `models`
--

INSERT INTO `models` (`id`, `producer_id`, `model`) VALUES
(1, 1, 'Cerato'),
(2, 1, 'Ceed'),
(3, 1, 'Picanto'),
(4, 1, 'Optima'),
(5, 2, 'Accent'),
(6, 2, 'Santa Fe'),
(7, 2, 'IX35'),
(8, 2, 'Solaris'),
(9, 1, 'Rio'),
(10, 2, 'Getz'),
(11, 3, 'Granta'),
(12, 3, 'Priora'),
(13, 3, 'Kalina'),
(14, 3, 'Samara'),
(15, 3, '4x4'),
(16, 4, 'Aveo'),
(17, 4, 'Lacetti'),
(18, 4, 'Cobalt'),
(19, 4, 'Cruze'),
(20, 4, 'Captiva'),
(26, 5, 'Vectra'),
(27, 5, 'Mokka'),
(28, 5, 'Astra'),
(29, 5, 'Corsa');

