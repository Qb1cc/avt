<?php
/**
 *  файл functions.php
 *  Здесь размещены функции, получающие данные из MySQL для полей формы
 */

/**
 *  Подключаем файл с нашими объявлениями классов DB и MyPDOException
 */
require_once( 'db.php' );
require_once( 'mypdoexception.php' );
/**
 *  Функция для получения перечня производителей автомобилей
 */
function getProducers() {
	
	/** Более этот код не актуален
	 *  Мы будем подключаться к СУБД MySQL через класс DB
	 */
	 
	// Подключаемся к СУБД MySQL
	// connect();
	$dbh = DB::instance();
	
	// Выбираем всех производителей из таблицы
	$sql = "SELECT * FROM `producers` ORDER BY `producer`";
	
	/**
	 * Этот код более не актуален
	 */
	// Выполняем запрос
	// $query = mysql_query( $sql ) or die ( mysql_error() );
	
	// Поместим данные, которые будет возвращать функция, в массив
	// Пока что он будет пустым
	$array = array();
	
	// Инициализируем счетчик
	$i = 0;
	
	/** Это устаревшая часть кода **/
	/*while ( $row = mysql_fetch_assoc( $query ) ) {
		
		$array[ $i ][ 'id' ] = $row[ 'id' ];				// Идентификатор производителя
		$array[ $i ][ 'producer' ] = $row[ 'producer' ];	// Имя производителя
		
		// После каждой итерации цикла увеличиваем счетчик
		$i++;
		
	}*/
	
	try { 
	
		foreach( $dbh->query( $sql ) as $row ) {
			
			$array[ $i ][ 'id' ] = $row[ 'id' ];				// Идентификатор производителя
			$array[ $i ][ 'producer' ] = $row[ 'producer' ];	// Имя производителя
			
			// После каждой итерации цикла увеличиваем счетчик
			$i++;
			
		}
	
	}
	catch ( PDOException $e ) {
		
		MyPDOException::instance( $e );
		
	}
	
	// Возвращаем вызову функции массив с данными
	return $array;
	
}

// Функция, которая выбирает модели автомобилей по переданному
// ей идентификатору производителя
function getModels( array $array ) {
	
	// Сохраняем идентификатор производителя из переданного массива
	$sProducerId = htmlspecialchars( trim ( $array[ 'producer_id' ] ) );
	
	/** Это устаревшая часть кода **/
	// Подключаемся к MySQL
	// connect();
	
	$dbh = DB::instance();
	
	// Строка запроса из базы данных
	$sql = "SELECT `id`, `model` FROM `models` WHERE `producer_id` = '" . $sProducerId . "' ORDER BY `model`";
	
	/** Это устаревшая часть кода **/
	// Выполняем запрос
	// $query = mysql_query( $sql ) or die ( mysql_error() );
	
	// Поместим данные, которые будет возвращать функция, в массив
	// Пока что он будет пустым
	$array = array();
	
	// Инициализируем счетчик
	$i = 0;
	
	/** Это устаревшая часть кода **/
	/*while ( $row = mysql_fetch_assoc( $query ) ) {
		
		$array[ $i ][ 'id' ] = $row[ 'id' ];		// Идентификатор модели
		$array[ $i ][ 'model' ] = $row[ 'model' ];	// Наименование модели
		
		// После каждой итерации цикла увеличиваем счетчик
		$i++;
		
	}*/
	
	foreach( $dbh->query( $sql ) as $row ) {
		
		$array[ $i ][ 'id' ] = $row[ 'id' ];		// Идентификатор модели
		$array[ $i ][ 'model' ] = $row[ 'model' ];	// Наименование модели
		
		// После каждой итерации цикла увеличиваем счетчик
		$i++;
		
	}
	
	// Возвращаем вызову функции массив с данными
	return $array;
	
}
?>